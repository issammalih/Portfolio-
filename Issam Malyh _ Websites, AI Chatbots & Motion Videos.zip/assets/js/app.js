/* ========= Edit your details here ========= */
const CONFIG = {
  email: "issammalyh@gmail.com",
  linkedin: "https://www.linkedin.com/",   // your LinkedIn profile URL
  calendar: "",                            // optional: Calendly link
  chatApi: "",                             // optional: Cloudflare Worker URL for a real OpenAI brain. NEVER put an API key in this file.
  formKey: ""                              // after activating FormSubmit, paste the random alias it gives you here to hide your email from bots
};

/* ===== Security: anti-framing on the live site, spam limits ===== */
if (window.top !== window.self && /github\.io$/.test(location.hostname)) { document.documentElement.style.display = "none"; try { window.top.location = window.self.location.href; } catch(e){} }
const GUARD = {
  loaded: Date.now(),
  clean: (v, max) => String(v ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, max),
  isEmail: v => /^[^\s@<>()]{1,64}@[^\s@<>()]{1,180}\.[a-z]{2,24}$/i.test(v),
  tooManyLinks: v => (String(v).match(/https?:\/\/|www\./gi) || []).length > 3,
  recent(){ try { const t = JSON.parse(localStorage.getItem("im_sent") || "[]").filter(x => Date.now() - x < 3600e3); return t; } catch(e){ return []; } },
  allow(){ return this.recent().length < 3; },
  mark(){ try { const t = this.recent(); t.push(Date.now()); localStorage.setItem("im_sent", JSON.stringify(t)); } catch(e){} }
};

const ANNOUNCEMENTS = [
  "<b>Now booking</b> new website and chatbot projects",
  "<b>Free 30-minute call</b> with a clear, fixed-price proposal",
  "<b>New:</b> add an AI chatbot to any website in a few days"
];

const PROJECTS = [
  { id:"imsystems", name:"IM Systems", cat:"Agency website + AI chatbot", url:"https://issammalih.github.io/Verto-6/",
    text:"A premium website for a web and AI studio. One clear promise above the fold, transparent pricing, real projects and a live AI agent that answers visitors in three languages.",
    meta:[["Industry","Digital agency"],["Delivered","Design, code, chatbot"],["Languages","EN, ES, AR"]] },
  { id:"carrr", name:"Auto Youssef", cat:"Car marketplace", url:"https://issammalih.github.io/Carrr/",
    text:"A car marketplace where buyers filter by brand, budget, year and fuel, with a built-in chatbot that answers financing and trade-in questions.",
    meta:[["Industry","Automotive"],["Delivered","Design, code, chatbot"],["Key feature","Smart search"]] },
  { id:"alami", name:"Dr. Alami Dental Clinic", cat:"Healthcare website", url:"https://issammalih.github.io/ALAMI/",
    text:"A calm, trustworthy website for a dental clinic: treatments, emergencies, patient reviews and an online form that turns visitors into booked appointments.",
    meta:[["Industry","Healthcare"],["Delivered","Design and code"],["Key feature","Online booking"]] },
  { id:"verto1", name:"Verto Media: Results", cat:"Marketing agency, direction 1 of 4", url:"https://issammalih.github.io/VERTO1-/",
    text:"A dark, results-driven direction for an international marketing agency, built around case studies, live numbers and a dashboard preview.",
    meta:[["Industry","Marketing"],["Delivered","Art direction, code"],["Style","Dark, data-led"]] },
  { id:"verto2", name:"Verto Media: Smart Growth", cat:"Marketing agency, direction 2 of 4", url:"https://issammalih.github.io/VERTO2/",
    text:"A product-style direction with an email capture in the hero and a campaign performance dashboard that makes the offer feel tangible.",
    meta:[["Industry","Marketing"],["Delivered","Art direction, code"],["Style","SaaS, product-led"]] },
  { id:"verto3", name:"Verto Media: Light", cat:"Marketing agency, direction 3 of 4", url:"https://issammalih.github.io/Verto3-/",
    text:"A bright, friendly direction with a simple promise and a campaign board that shows how the agency organises work.",
    meta:[["Industry","Marketing"],["Delivered","Art direction, code"],["Style","Light, friendly"]] },
  { id:"verto4", name:"Verto Media: Premium", cat:"Marketing agency, direction 4 of 4", url:"https://issammalih.github.io/Verto-4/",
    text:"A bold black and orange direction for ambitious brands, with campaign results presented like a real product.",
    meta:[["Industry","Marketing"],["Delivered","Art direction, code"],["Style","Bold, premium"]] }
];

const FILMS = [
  { src:"assets/videos/cloudhealth-control.mp4", thumb:"assets/thumbs/cloudhealth-control.jpg", tag:"Launch film for CloudHealth by Broadcom", title:"Control your cloud", text:"Global reach, rightsizing and savings explained in 37 seconds.", dur:"0:37", fmt:"16:9" },
  { src:"assets/videos/automated-optimisation.mp4", thumb:"assets/thumbs/automated-optimisation.jpg", tag:"Product promo", title:"Automated optimisation", text:"AWS, Azure and GCP connected in one cinematic product story.", dur:"1:03", fmt:"16:9" },
  { src:"assets/videos/economics-of-cloud.mp4", thumb:"assets/thumbs/economics-of-cloud.jpg", tag:"Webinar promo", title:"AI, FinOps & Tokenomics", text:"Event teaser for a CloudHealth and Arrow webinar.", dur:"0:32", fmt:"16:9" },
  { src:"assets/videos/ai-tokenomics.mp4", thumb:"assets/thumbs/ai-tokenomics.jpg", tag:"Explainer", title:"The state of tokenomics", text:"From a messy AI bill to clear, user-level dashboards.", dur:"0:45", fmt:"4:5 social" },
  { src:"assets/videos/ai-spend-governance.mp4", thumb:"assets/thumbs/ai-spend-governance.jpg", tag:"LinkedIn ad", title:"Who owns AI spending?", text:"Vertical ad on AI spend governance with a clear call to book a demo.", dur:"0:37", fmt:"4:5 social" }
];

/* Client cities on the globe: edit freely */
const HOME = { city:"Casablanca", lat:33.57, lon:-7.59 };
const LOCATIONS = [
  { city:"London", country:"United Kingdom", lat:51.51, lon:-0.13, region:"Europe" },
  { city:"Paris", country:"France", lat:48.86, lon:2.35, region:"Europe" },
  { city:"Madrid", country:"Spain", lat:40.42, lon:-3.70, region:"Europe" },
  { city:"Milan", country:"Italy", lat:45.46, lon:9.19, region:"Europe" },
  { city:"Munich", country:"Germany", lat:48.14, lon:11.58, region:"Europe" },
  { city:"Dubai", country:"UAE", lat:25.20, lon:55.27, region:"Middle East" },
  { city:"New York", country:"United States", lat:40.71, lon:-74.01, region:"North America" },
  { city:"Boston", country:"United States", lat:42.36, lon:-71.06, region:"North America" },
  { city:"California", country:"United States", lat:34.05, lon:-118.24, region:"North America" },
  { city:"Quebec", country:"Canada", lat:46.81, lon:-71.21, region:"North America" },
  { city:"Rio de Janeiro", country:"Brazil", lat:-22.91, lon:-43.17, region:"South America" },
  { city:"Buenos Aires", country:"Argentina", lat:-34.60, lon:-58.38, region:"South America" }
];

const STACK = [
  ["Figma","UI/UX design","#A259FF"],["HTML & CSS","Front-end","#E44D26"],["JavaScript","Interactions","#E6B800"],["OpenAI","AI chatbots","#10A37F"],
  ["n8n","Automation","#EA4B71"],["Salesforce","CRM","#00A1E0"],["Shopify","E-commerce","#5E8E3E"],["GitHub","Hosting","#24292F"],
  ["Cloudflare","AI workers","#F38020"],["Three.js","3D web","#4B3BF5"]
];

const $ = (s,el=document)=>el.querySelector(s);
const $$ = (s,el=document)=>[...el.querySelectorAll(s)];
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
const isTouch = matchMedia("(hover:none)").matches;

/* load sequence */
const ready = ()=> document.body.classList.add("ready");
if (document.readyState === "complete") ready(); else addEventListener("load", ready);
setTimeout(ready, 2000);

/* announcement */
(function(){
  const box = $("#annRot");
  box.innerHTML = ANNOUNCEMENTS.map((t,i)=>`<span class="${i?'':'on'}">${t}</span>`).join("");
  const items = $$("span", box); let cur = 0;
  if (reduce) return;
  setInterval(()=>{ const o = cur; items[o].classList.remove("on"); items[o].classList.add("out"); setTimeout(()=>items[o].classList.remove("out"),650); cur = (cur+1)%items.length; items[cur].classList.add("on"); }, 4200);
})();

/* nav + progress */
const nav = $("#nav"), menuBtn = $("#menuBtn");
menuBtn.addEventListener("click", ()=>{ const o = nav.classList.toggle("open"); menuBtn.setAttribute("aria-expanded", o); });
$$("#menu a").forEach(a=>a.addEventListener("click", ()=>{ nav.classList.remove("open"); menuBtn.setAttribute("aria-expanded", false); }));
const sections = $$("main section[id]");
function onScroll(){
  nav.classList.toggle("stuck", scrollY > 10);
  $("#progress").style.width = (scrollY / (document.documentElement.scrollHeight - innerHeight) * 100) + "%";
  let cur = "";
  sections.forEach(s=>{ if (s.getBoundingClientRect().top < innerHeight*.35) cur = s.id; });
  $$("#menu a").forEach(a=>a.classList.toggle("on", a.getAttribute("href") === "#"+cur));
}
addEventListener("scroll", onScroll, {passive:true}); onScroll();

/* word split for headings */
$$(".words").forEach(h=>{ let i = 0; h.innerHTML = h.textContent.split(" ").map(w=>`<span class="w"><span style="--i:${i++}">${w}</span></span>`).join(" "); });

/* reveal observer */
const io = new IntersectionObserver(es=>es.forEach(e=>{ if (e.isIntersecting){ e.target.classList.add("in"); $$(".words",e.target).forEach(w=>w.classList.add("in")); io.unobserve(e.target); } }), {threshold:.15, rootMargin:"0px 0px -60px 0px"});
$$(".reveal,.sec-head").forEach(el=>io.observe(el));

/* 3D tilt on service cards */
if (!isTouch && !reduce) $$(".svc").forEach(c=>{
  c.addEventListener("pointermove", e=>{ const r = c.getBoundingClientRect(), x = (e.clientX-r.left)/r.width-.5, y = (e.clientY-r.top)/r.height-.5;
    c.style.transform = `rotateY(${x*12}deg) rotateX(${-y*12}deg) translateZ(10px)`; c.style.setProperty("--mx",(e.clientX-r.left)+"px"); c.style.setProperty("--my",(e.clientY-r.top)+"px"); });
  c.addEventListener("pointerleave", ()=> c.style.transform = "");
});

/* ===== Site-wide 3D background: particle wave (fixed, reacts to mouse and scroll) ===== */
(function(){
  if (!window.THREE) return;
  const canvas = $("#hero3d");
  const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio, innerWidth < 700 ? 1.5 : 2));
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, .1, 200); camera.position.set(0, 2.2, 16);
  const small = innerWidth < 700, NX = small ? 64 : 130, NZ = small ? 34 : 54, SP = small ? .6 : .45;
  const pos = new Float32Array(NX*NZ*3), col = new Float32Array(NX*NZ*3);
  const c1 = new THREE.Color(0x4B3BF5), c2 = new THREE.Color(0xB9ACFF), tc = new THREE.Color();
  for (let i=0;i<NX;i++) for (let j=0;j<NZ;j++){ const k=(i*NZ+j)*3; pos[k]=(i-NX/2)*SP; pos[k+1]=0; pos[k+2]=(j-NZ/2)*SP; tc.copy(c1).lerp(c2, j/NZ); col[k]=tc.r; col[k+1]=tc.g; col[k+2]=tc.b; }
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos,3)); pg.setAttribute("color", new THREE.BufferAttribute(col,3));
  const dotTex = (()=>{ const c=document.createElement("canvas"); c.width=c.height=64; const x=c.getContext("2d"); const g=x.createRadialGradient(32,32,0,32,32,32); g.addColorStop(0,"rgba(255,255,255,1)"); g.addColorStop(.45,"rgba(255,255,255,.9)"); g.addColorStop(1,"rgba(255,255,255,0)"); x.fillStyle=g; x.fillRect(0,0,64,64); return new THREE.CanvasTexture(c); })();
  const points = new THREE.Points(pg, new THREE.PointsMaterial({size:.13, map:dotTex, vertexColors:true, transparent:true, opacity:.6, depthWrite:false}));
  points.position.set(0,-6.6,-6); scene.add(points);
  let mx=0, my=0, sy=scrollY;
  addEventListener("pointermove", e=>{ mx=e.clientX/innerWidth-.5; my=e.clientY/innerHeight-.5; }, {passive:true});
  function size(){ renderer.setSize(innerWidth, innerHeight, false); camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix(); }
  addEventListener("resize", size); size();
  const t0 = performance.now();
  (function loop(){
    requestAnimationFrame(loop);
    if (document.hidden) return;
    const t = reduce ? 0 : (performance.now()-t0)/1000;
    sy += (scrollY - sy)*.08; const s = sy*.0025;
    const a = pg.attributes.position.array;
    for (let i=0;i<NX;i++) for (let j=0;j<NZ;j++){ const k=(i*NZ+j)*3, x=a[k], z=a[k+2]; a[k+1] = Math.sin(x*.35 + t*.9 + s)*.55 + Math.cos(z*.5 + t*.7 - s*.6)*.45 + Math.sin((x+z)*.18 + t*.5)*.4; }
    pg.attributes.position.needsUpdate = true;
    points.rotation.y = Math.sin(t*.08)*.08 + Math.sin(s*.3)*.05;
    camera.position.x += (mx*1.6 - camera.position.x)*.04; camera.position.y += (2.2 - my*1.2 - camera.position.y)*.04; camera.lookAt(0,0,0);
    renderer.render(scene, camera);
  })();
})();

/* ===== Work: horizontal 3D gallery pinned to scroll ===== */
(function(){
  const sec = $("#work"), track = $("#track");
  const arrow = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M7 17L17 7M8 7h9v9"/></svg>';
  track.innerHTML = PROJECTS.map((p,i)=>`<article class="pcard"><span class="pnum">0${i+1}</span>
    <button type="button" class="pshot" data-i="${i}" aria-label="View ${p.name} full size"><div class="browser"><div class="browser-bar"><i></i><i></i><i></i><em>${p.url.replace("https://","")}</em></div><img src="assets/work/${p.id}-desktop.webp" alt="${p.name} website on desktop" width="1440" height="900" loading="lazy"></div><div class="phone"><img src="assets/work/${p.id}-mobile.webp" alt="" loading="lazy"></div></button>
    <div class="pmeta2"><div><small>${p.cat}</small><h3>${p.name}</h3><p>${p.text}</p><div class="ptags">${p.meta.map(m=>`<span>${m[1]}</span>`).join("")}</div></div><a class="pgo" href="${p.url}" target="_blank" rel="noopener noreferrer" aria-label="Visit ${p.name} live site">${arrow}</a></div></article>`).join("")
    + `<article class="pcard next"><div class="pshot"><div><h3>Your project could be next</h3><p>Tell me about your business and get a fixed-price proposal within 24 hours.</p><a class="btn" href="#contact">Book a free call</a></div></div></article>`;
  $("#wAll").textContent = PROJECTS.length;
  $$("button.pshot", track).forEach(b=>b.addEventListener("click", ()=>{ const p = PROJECTS[+b.dataset.i]; openModal(`<img src="assets/work/${p.id}-desktop.webp" alt="${p.name}">`, p.name); }));
  const cards = $$(".pcard", track), mq = matchMedia("(max-width:860px)");
  let maxX = 0;
  function layout(){
    if (mq.matches){ sec.style.height=""; track.style.transform=""; cards.forEach(c=>{ c.style.transform=""; c.style.opacity=""; }); return; }
    maxX = Math.max(0, track.scrollWidth - innerWidth); sec.style.height = (maxX + innerHeight) + "px"; update();
  }
  function update(){
    if (mq.matches) return;
    const r = sec.getBoundingClientRect(), p = Math.min(Math.max(-r.top/Math.max(1, sec.offsetHeight-innerHeight),0),1), x = p*maxX, cx = innerWidth/2;
    track.style.transform = `translate3d(${-x}px,0,0)`;
    let best = 0, bd = 1e9;
    cards.forEach((c,i)=>{ const d = (c.offsetLeft + c.offsetWidth/2 - x - cx)/innerWidth, ad = Math.min(Math.abs(d),1);
      c.style.transform = `rotateY(${Math.max(-1,Math.min(1,d))*-24}deg) scale(${1-ad*.14})`; c.style.opacity = 1-ad*.4;
      if (ad < bd && i < PROJECTS.length){ bd = ad; best = i; } });
    $("#wNow").textContent = String(best+1).padStart(2,"0"); $("#wBar").style.width = (p*100)+"%";
  }
  addEventListener("scroll", ()=>requestAnimationFrame(update), {passive:true});
  addEventListener("resize", layout); mq.addEventListener("change", layout);
  addEventListener("load", layout); layout();
})();

/* ===== Creative 1: laptop opens on scroll ===== */
(function(){
  const sec = $("#devices"), lap = $("#laptop"), scr = $("#lscreen"), ph = $("#dphone"), steps = $$("#dsteps li");
  const shots = ["imsystems","carrr","alami","verto4"];
  scr.innerHTML = shots.map((s,i)=>`<img src="assets/work/${s}-desktop.webp" alt="" class="${i?'':'on'}" loading="lazy">`).join("");
  const imgs = $$("img", scr), phones = ["imsystems","carrr","alami","verto4"];
  let last = -1;
  const ease = t=>1-Math.pow(1-t,3);
  function update(){
    const r = sec.getBoundingClientRect(), total = sec.offsetHeight - innerHeight;
    const p = Math.min(Math.max(-r.top/total,0),1);
    const open = ease(Math.min(p/.35,1));
    lap.style.setProperty("--lid", `${-90 + 90*open}deg`);
    lap.style.setProperty("--rx", `${55 - 45*open}deg`);
    lap.style.setProperty("--ry", `${-25 + 25*open - (p>.35 ? (p-.35)*20 : 0)}deg`);
    lap.style.setProperty("--rz", `${6 - 6*open}deg`);
    const po = Math.min(Math.max((p-.3)/.15,0),1);
    ph.style.setProperty("--po", po); ph.style.setProperty("--py", `${80 - 80*po}px`); ph.style.setProperty("--pr", `${8 - 14*po}deg`);
    const idx = Math.min(shots.length-1, Math.floor(Math.max(p-.3,0)/.7*shots.length));
    if (idx !== last){ last = idx; imgs.forEach((im,k)=>im.classList.toggle("on", k===idx)); steps.forEach((s,k)=>s.classList.toggle("on", k===idx)); $("img", ph).src = `assets/work/${phones[idx]}-mobile.webp`; }
  }
  addEventListener("scroll", ()=>requestAnimationFrame(update), {passive:true}); addEventListener("resize", update); update();
})();

/* ===== Videos: 3D coverflow with live previews ===== */
(function(){
  const stage = $("#cfStage"), n = FILMS.length; let cur = 0, inView = false;
  const play = '<svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg>';
  stage.innerHTML = FILMS.map((f,i)=>`<div class="vcard" data-i="${i}" role="button" tabindex="0" aria-label="${f.title}"><video muted loop playsinline preload="none" poster="${f.thumb}" src="${f.src}"></video><span class="vplay">${play}</span><span class="vbadge"><span class="live">● Preview</span><span>${f.dur}</span></span></div>`).join("");
  const cards = $$(".vcard", stage), vids = cards.map(c=>$("video", c));
  $("#cfDots").innerHTML = FILMS.map((f,i)=>`<button type="button" aria-label="Show video ${i+1}"></button>`).join("");
  const dots = $$("#cfDots button"), info = $("#cfInfo");
  function render(){
    const small = innerWidth < 700;
    cards.forEach((c,i)=>{ let k = i-cur; if (k > n/2) k -= n; if (k < -n/2) k += n; const a = Math.abs(k);
      c.style.transform = `translateX(${k*(small?70:60)}%) translateZ(${-a*260}px) rotateY(${-k*34}deg)`;
      c.style.opacity = a>2 ? 0 : 1-a*.22; c.style.zIndex = 10-a; c.style.filter = a ? `brightness(${1-a*.15})` : "none";
      c.style.pointerEvents = a>2 ? "none" : "auto"; c.classList.toggle("on", k===0); });
    dots.forEach((d,i)=>d.classList.toggle("on", i===cur));
    vids.forEach((v,i)=>{ if (i===cur && inView && !reduce) v.play().catch(()=>{}); else v.pause(); });
    const f = FILMS[cur]; info.classList.add("swap");
    setTimeout(()=>{ $("#vTag").textContent=f.tag; $("#vTitle").textContent=f.title; $("#vText").textContent=f.text; $("#vFmt").textContent=f.fmt; $("#vDur").textContent=f.dur; info.classList.remove("swap"); }, 250);
  }
  const go = i => { cur = (i+n)%n; render(); };
  const watch = ()=>{ vids.forEach(v=>v.pause()); const f = FILMS[cur]; openModal(`<video src="${f.src}" poster="${f.thumb}" controls autoplay playsinline></video>`, f.title); };
  $("#cfPrev").onclick = ()=>go(cur-1); $("#cfNext").onclick = ()=>go(cur+1); $("#vWatch").onclick = watch;
  dots.forEach((d,i)=>d.onclick = ()=>go(i));
  cards.forEach((c,i)=>{ c.addEventListener("click", ()=> i===cur ? watch() : go(i)); c.addEventListener("keydown", e=>{ if (e.key==="Enter"||e.key===" "){ e.preventDefault(); i===cur ? watch() : go(i); } }); });
  let sx = null; const cf = $("#cf");
  cf.addEventListener("pointerdown", e=>{ sx = e.clientX; });
  cf.addEventListener("pointerup", e=>{ if (sx===null) return; const dx = e.clientX-sx; sx = null; if (Math.abs(dx) > 50){ go(cur + (dx<0?1:-1)); } });
  new IntersectionObserver(es=>{ inView = es[0].isIntersecting; vids.forEach((v,i)=>{ if (i===cur && inView && !reduce) v.play().catch(()=>{}); else v.pause(); }); }, {threshold:.3}).observe(cf);
  addEventListener("resize", render); render();
})();

/* ===== Creative 2: live, realistic 3D Earth ===== */
(function(){
  const box = $("#globeBox"), canvas = $("#globe");
  // region chips
  const regions = [...new Set(LOCATIONS.map(l=>l.region))];
  $("#regions").innerHTML = regions.map(r=>`<div class="region"><h4>${r}</h4><div class="cities">${LOCATIONS.map((l,i)=>l.region===r?`<button type="button" data-i="${i}"><i></i>${l.city}</button>`:"").join("")}</div></div>`).join("");
  const chips = $$("#regions button");
  // twinkling stars
  (function(){ const c=$("#stars"), x=c.getContext("2d"); let st=[];
    function rs(){ const r=c.parentElement.getBoundingClientRect(); c.width=r.width; c.height=r.height; st=Array.from({length:Math.round(r.width*r.height/5000)},()=>({x:Math.random()*r.width,y:Math.random()*r.height,s:Math.random()*1.3+.2,p:Math.random()*6})); }
    rs(); addEventListener("resize", rs);
    (function tw(t){ requestAnimationFrame(tw); x.clearRect(0,0,c.width,c.height); st.forEach(s=>{ x.globalAlpha=.25+.6*Math.abs(Math.sin(t/1600+s.p)); x.fillStyle="#7A6BFF"; x.fillRect(s.x,s.y,s.s,s.s); }); })(0);
  })();
  if (!window.THREE) return;
  const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, .1, 100); camera.position.set(0,0,11.4);
  const R = 2.6, earth = new THREE.Group(); scene.add(earth);
  const L = new THREE.TextureLoader(), tex = u=>{ const t=L.load(u); t.anisotropy=renderer.capabilities.getMaxAnisotropy(); return t; };
  const sun = new THREE.Vector3(-.75,.35,.62).normalize();
  const earthMat = new THREE.ShaderMaterial({
    uniforms:{ day:{value:tex("assets/img/earth-real.jpg")}, night:{value:tex("assets/img/earth-night.jpg")}, spec:{value:tex("assets/img/earth-water.jpg")}, sunDir:{value:sun} },
    vertexShader:`varying vec2 vUv;varying vec3 vN;varying vec3 vW;void main(){vUv=uv;vN=normalize(mat3(modelMatrix)*normal);vec4 w=modelMatrix*vec4(position,1.0);vW=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,
    fragmentShader:`uniform sampler2D day;uniform sampler2D night;uniform sampler2D spec;uniform vec3 sunDir;varying vec2 vUv;varying vec3 vN;varying vec3 vW;
    void main(){vec3 n=normalize(vN);float d=dot(n,sunDir);float m=smoothstep(-0.12,0.28,d);
      vec3 dc=texture2D(day,vUv).rgb;dc=pow(dc,vec3(0.95))*1.08;
      vec3 nc=texture2D(night,vUv).rgb;nc=nc*vec3(1.0,0.82,0.55)*1.7;
      vec3 lit=dc*(0.18+0.95*max(d,0.0));
      vec3 col=mix(nc+dc*0.035,lit,m);
      vec3 V=normalize(cameraPosition-vW);vec3 H=normalize(sunDir+V);
      float s=texture2D(spec,vUv).r;col+=vec3(0.8,0.85,1.0)*pow(max(dot(n,H),0.0),55.0)*s*0.75*m;
      float f=pow(1.0-max(dot(n,V),0.0),3.0);col+=vec3(0.42,0.36,1.0)*f*(0.25+0.75*m)*0.9;
      gl_FragColor=vec4(col,1.0);}`
  });
  earth.add(new THREE.Mesh(new THREE.SphereGeometry(R,128,128), earthMat));
  const clouds = new THREE.Mesh(new THREE.SphereGeometry(R*1.008,96,96), new THREE.ShaderMaterial({
    uniforms:{map:{value:tex("assets/img/earth-clouds.jpg")}, sunDir:{value:sun}}, transparent:true, depthWrite:false,
    vertexShader:`varying vec2 vUv;varying vec3 vN;void main(){vUv=uv;vN=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
    fragmentShader:`uniform sampler2D map;uniform vec3 sunDir;varying vec2 vUv;varying vec3 vN;void main(){float a=texture2D(map,vUv).r;float d=dot(normalize(vN),sunDir);float l=smoothstep(-0.15,0.35,d);gl_FragColor=vec4(vec3(0.95,0.96,1.0)*(0.08+0.92*l),a*0.85*(0.25+0.75*l));}`
  }));
  earth.add(clouds);
  // soft violet atmosphere
  scene.add(new THREE.Mesh(new THREE.SphereGeometry(R*1.14,64,64), new THREE.ShaderMaterial({
    uniforms:{c:{value:new THREE.Color(0x7E63FF)}}, side:THREE.BackSide, transparent:true, depthWrite:false,
    vertexShader:"varying vec3 vN;varying vec3 vP;void main(){vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.0);vP=mv.xyz;gl_Position=projectionMatrix*mv;}",
    fragmentShader:"uniform vec3 c;varying vec3 vN;varying vec3 vP;void main(){float d=dot(vN,normalize(-vP));float i=pow(clamp(-d/0.48,0.0,1.0),2.6);gl_FragColor=vec4(c,i*0.75);}"
  })));
  const toVec = (lat,lon,r)=>{ const phi=(90-lat)*Math.PI/180, th=(lon+180)*Math.PI/180; return new THREE.Vector3(-r*Math.sin(phi)*Math.cos(th), r*Math.cos(phi), r*Math.sin(phi)*Math.sin(th)); };
  const pins = [];
  const mkPin = (l,home)=>{
    const p = toVec(l.lat,l.lon,R*1.004);
    const dot = new THREE.Mesh(new THREE.SphereGeometry(home?.05:.038,16,16), new THREE.MeshBasicMaterial({color:home?0x8CF5C8:0xffffff})); dot.position.copy(p); earth.add(dot);
    const ring = new THREE.Mesh(new THREE.RingGeometry(.05,.068,40), new THREE.MeshBasicMaterial({color:home?0x8CF5C8:0xB9A8FF, transparent:true, side:THREE.DoubleSide, depthWrite:false}));
    ring.position.copy(p); ring.lookAt(p.clone().multiplyScalar(2)); earth.add(ring);
    const lab = document.createElement("div"); lab.className = "glabel"+(home?" home":""); lab.textContent = home ? l.city+" · HQ" : l.city; box.appendChild(lab);
    pins.push({p, ring, lab, home});
  };
  LOCATIONS.forEach(l=>mkPin(l,false)); mkPin(HOME,true);
  const homeV = toVec(HOME.lat,HOME.lon,R), arcs = [];
  LOCATIONS.forEach((l,i)=>{
    const end = toVec(l.lat,l.lon,R), mid = homeV.clone().add(end).multiplyScalar(.5), dist = homeV.distanceTo(end);
    mid.normalize().multiplyScalar(R + dist*.32);
    const curve = new THREE.QuadraticBezierCurve3(homeV, mid, end);
    const geo = new THREE.TubeGeometry(curve, 80, .007, 6, false);
    earth.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({color:0xC9BCFF, transparent:true, opacity:.9, depthWrite:false})));
    const dot = new THREE.Mesh(new THREE.SphereGeometry(.022,10,10), new THREE.MeshBasicMaterial({color:0xffffff})); earth.add(dot);
    arcs.push({geo, total:geo.index.count, curve, dot, off:i*.37});
  });
  const rotFor = l => ({ y: -(l.lon+90)*Math.PI/180, x: Math.max(-.6, Math.min(.6, l.lat*Math.PI/180*.85)) });
  const start = rotFor({lat:28, lon:-38}); earth.rotation.set(start.x, start.y, 0);
  let dragging=false, px=0, py=0, vy=0, visible=false, auto=true, target=null, active=-1, idleT=null;
  const setActive = i => { active=i; chips.forEach((c,k)=>c.classList.toggle("on",k===i)); };
  const resume = ()=>{ clearTimeout(idleT); idleT=setTimeout(()=>{ auto=true; }, 3500); };
  canvas.addEventListener("pointerdown", e=>{ dragging=true; px=e.clientX; py=e.clientY; auto=false; target=null; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener("pointermove", e=>{ if(!dragging) return; vy=(e.clientX-px)*.006; earth.rotation.y+=vy; earth.rotation.x=Math.max(-.8,Math.min(.8,earth.rotation.x+(e.clientY-py)*.004)); px=e.clientX; py=e.clientY; });
  addEventListener("pointerup", ()=>{ if(dragging){ dragging=false; resume(); } });
  chips.forEach(c=>c.addEventListener("click", ()=>{ const i=+c.dataset.i; setActive(i); target=rotFor(LOCATIONS[i]); auto=false; }));
  new IntersectionObserver(es=>{ visible=es[0].isIntersecting; }, {threshold:.05}).observe(box);
  function size(){ const w=box.clientWidth; renderer.setSize(w,w,false); camera.aspect=1; camera.updateProjectionMatrix(); }
  addEventListener("resize", size); size();
  const tmp=new THREE.Vector3(), nrm=new THREE.Vector3(), camDir=new THREE.Vector3(), t0=performance.now();
  let tour=0, lastTour=0;
  (function loop(){
    requestAnimationFrame(loop);
    if (!visible) return;
    const t=(performance.now()-t0)/1000;
    if (target){ let dy=target.y-earth.rotation.y; dy=Math.atan2(Math.sin(dy),Math.cos(dy)); earth.rotation.y+=dy*.055; earth.rotation.x+=(target.x-earth.rotation.x)*.055; if(Math.abs(dy)<.003){ target=null; resume(); } }
    else if (auto && !dragging && !reduce){ earth.rotation.y+=.0018; earth.rotation.x+=(.3-earth.rotation.x)*.01;
      if (t-lastTour>3.2){ lastTour=t; // highlight the most front-facing city
        let best=-1,bd=-2; LOCATIONS.forEach((l,i)=>{ tmp.copy(pins[i].p); earth.localToWorld(tmp); const dd=tmp.normalize().z; if(dd>bd && i!==active){bd=dd;best=i;} }); setActive(best); } }
    else if (!dragging){ earth.rotation.y+=(vy*=.94); }
    clouds.rotation.y=t*.01;
    pins.forEach((m,i)=>{ const q=(t*.7+i*.13)%1; m.ring.scale.setScalar(1+q*2.6); m.ring.material.opacity=(1-q)*(m.home||i===active?1:.6); });
    arcs.forEach(a=>{ const k=Math.min(1,Math.max(0,(t*.5-a.off*.35))); a.geo.setDrawRange(0,Math.floor(a.total*k)); a.dot.position.copy(a.curve.getPoint((t*.28+a.off)%1)); a.dot.visible=k>=1; });
    renderer.render(scene,camera);
    // labels with simple collision avoidance
    const w=box.clientWidth, placed=[];
    const order=pins.map((m,i)=>i).sort((a,b)=>(b===active)-(a===active)||(pins[b].home)-(pins[a].home));
    order.forEach(i=>{ const m=pins[i]; tmp.copy(m.p); earth.localToWorld(tmp); nrm.copy(tmp).normalize(); const facing=nrm.z>.22;
      tmp.project(camera); const x=(tmp.x*.5+.5)*w, y=(-tmp.y*.5+.5)*w;
      const free=placed.every(p=>Math.abs(p[0]-x)>84||Math.abs(p[1]-y)>24);
      const show=facing&&free; if(show) placed.push([x,y]);
      m.lab.style.transform=`translate(${x}px,${y}px) translate(-50%,-150%)`; m.lab.classList.toggle("hide",!show); m.lab.classList.toggle("on",i===active); });
  })();
})();

/* ===== Creative 3: website assembles from 3D layers on scroll ===== */
(function(){
  const sec = $("#build"), iso = $("#iso"), wrap = $("#isoWrap"), steps = $$("#lsteps li"), layers = $$(".layer", iso);
  $("#tools").innerHTML = STACK.concat(STACK).map(([name,role,c])=>`<span><i style="background:${c}">${name.replace(/[^A-Za-z0-9]/g,"").slice(0,2)}</i>${name}</span>`).join("");
  const ease = t => t<.5 ? 2*t*t : 1-Math.pow(-2*t+2,2)/2;
  let tx = 0, ty = 0;
  function update(){
    const r = sec.getBoundingClientRect(), p = Math.min(Math.max((innerHeight - r.top)/(innerHeight + r.height),0),1);
    let s = p<.18 ? 0 : p<.42 ? ease((p-.18)/.24) : p<.6 ? 1 : p<.8 ? 1-ease((p-.6)/.2) : 0;
    if (reduce) s = 1;
    iso.style.setProperty("--gap", (s*(innerWidth<700?60:100))+"px");
    layers.forEach(l=>l.style.setProperty("--lo", s>.35 ? 1 : 0));
    const idx = p<.32 ? 0 : p<.46 ? 1 : p<.6 ? 2 : 3;
    steps.forEach((li,i)=>li.classList.toggle("on", i===idx));
    iso.style.setProperty("--tx", (56 - ty*10)+"deg"); iso.style.setProperty("--tz", (-38 + tx*14)+"deg");
  }
  wrap.addEventListener("pointermove", e=>{ const b = wrap.getBoundingClientRect(); tx = (e.clientX-b.left)/b.width-.5; ty = (e.clientY-b.top)/b.height-.5; update(); });
  wrap.addEventListener("pointerleave", ()=>{ tx = ty = 0; update(); });
  addEventListener("scroll", ()=>requestAnimationFrame(update), {passive:true}); addEventListener("resize", update); update();
})();

/* ===== Modal ===== */
const modal = $("#modal"); let lastFocus = null;
function openModal(html, cap){ if (typeof lenis!=="undefined" && lenis) lenis.stop(); lastFocus = document.activeElement; $("#modalMedia").innerHTML = html; $("#modalCap").textContent = cap; modal.classList.add("open"); modal.setAttribute("aria-hidden","false"); document.body.style.overflow = "hidden"; $("#modalClose").focus(); }
function closeModal(){ if (typeof lenis!=="undefined" && lenis) lenis.start(); modal.classList.remove("open"); modal.setAttribute("aria-hidden","true"); document.body.style.overflow = ""; setTimeout(()=>$("#modalMedia").innerHTML = "", 350); if (lastFocus) lastFocus.focus(); }
$("#modalClose").addEventListener("click", closeModal);
modal.addEventListener("click", e=>{ if (e.target === modal) closeModal(); });
addEventListener("keydown", e=>{ if (e.key==="Escape"){ if (modal.classList.contains("open")) closeModal(); $("#widget").classList.remove("open"); } });

/* ===== Contact ===== */
const ICON = {
  cal:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
  mail:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 6l-10 7L2 6"/></svg>',
  in:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="4"/><path d="M7 10v7M7 7v.01M11 17v-4a2 2 0 0 1 4 0v4M11 10v7"/></svg>',
  globe:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>'
};
$("#clinks").innerHTML = [
  CONFIG.calendar ? ["cal","Book a call","Pick a time that suits you",CONFIG.calendar] : null,
  ["mail","Email",CONFIG.email,"mailto:"+CONFIG.email],
  ["in","LinkedIn","Connect with me",CONFIG.linkedin],
  ["globe","Working with","Clients in the US and Europe, fully remote",""]
].filter(Boolean).map(([ic,l,v,h])=> h ? `<li><a href="${h}" ${h.startsWith("http")?'target="_blank" rel="noopener noreferrer"':''}><i>${ICON[ic]}</i><span><small>${l}</small><b>${v}</b></span></a></li>` : `<li><span class="row"><i>${ICON[ic]}</i><span><small>${l}</small><b>${v}</b></span></span></li>`).join("");
$("#year").textContent = new Date().getFullYear();

/* ===== Lead delivery: sends requests to your inbox via FormSubmit (no page reload) ===== */
async function sendLead(raw){
  // sanitise and limit every field before it leaves the browser
  const data = {}; const max = {name:80, email:120, company:120, service:60, message:2000, language:20, source:30};
  Object.keys(max).forEach(k => { if (raw[k] != null) data[k] = GUARD.clean(raw[k], max[k]); });
  if (raw._honey) return {success:"true"};                                   // bot filled the hidden field: pretend success, send nothing
  if (Date.now() - GUARD.loaded < 4000) return {success:"true"};            // submitted faster than a human can
  if (!GUARD.isEmail(data.email || "")) throw new Error("invalid email");
  if (GUARD.tooManyLinks(data.message || "")) throw new Error("spam");
  if (!GUARD.allow()) throw new Error("rate");
  const r = await fetch("https://formsubmit.co/ajax/" + (CONFIG.formKey || CONFIG.email), {
    method:"POST", headers:{"Content-Type":"application/json","Accept":"application/json"},
    body: JSON.stringify({ _subject:`New ${data.source||"website"} request: ${data.service||"project"}`, _template:"table", _captcha:"false", _honey:"", ...data }), referrerPolicy:"strict-origin-when-cross-origin"
  });
  const j = await r.json().catch(()=>({}));
  if (String(j.success) === "true" || /activat/i.test(j.message||"")) { GUARD.mark(); return j; } // first request triggers FormSubmit's activation email
  throw new Error(j.message || "send failed");
}
const mailtoLead = d => `mailto:${CONFIG.email}?subject=${encodeURIComponent("Project request: "+(d.service||""))}&body=${encodeURIComponent(Object.entries(d).filter(([k])=>!k.startsWith("_")&&k!=="source").map(([k,v])=>k+": "+v).join("\n"))}`;

/* ===== Contact form ===== */
(function(){
  const f = $("#sendForm");
  f.removeAttribute("action");
  f.addEventListener("submit", async e=>{
    e.preventDefault();
    const btn = $("button[type=submit]", f), d = Object.fromEntries(new FormData(f));
    Object.keys(d).forEach(k=>{ if (k.startsWith("_")) delete d[k]; });
    btn.disabled = true; btn.textContent = "Sending…";
    try {
      await sendLead({...d, source:"contact form"});
      f.innerHTML = `<div class="sent"><div class="sent-ic"><svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><path d="M20 6L9 17l-5-5"/></svg></div><h3>Thanks, ${esc(d.name)}!</h3><p>Your request was sent. I'll reply within 24 hours at <b>${esc(d.email)}</b>.</p><a class="btn btn-light" href="#work">See my work while you wait</a></div>`;
    } catch(err){
      btn.disabled = false; btn.textContent = "Send request";
      let n = $(".send-err", f); if (!n){ n = document.createElement("p"); n.className = "send-err"; btn.after(n); }
      if (err.message === "invalid email"){ n.textContent = "Please enter a valid email address."; return; }
      if (err.message === "spam"){ n.textContent = "Please remove some links from your message."; return; }
      if (err.message === "rate"){ n.textContent = "You've already sent a few requests. Issam will get back to you soon."; return; }
      n.innerHTML = location.protocol === "file:" ? `Sending works once the site is online (GitHub Pages). For now: <a href="${mailtoLead(d)}">send it by email</a>.` : `Your connection blocked the form. <a href="${mailtoLead(d)}">Send it by email instead</a>, your details are already filled in.`;
    }
  });
})();
function esc(s){ return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

/* ===== AI assistant logo ===== */
function botLogo(size, light){
  const bg = light ? "#fff" : "#5B4BFF", fg = light ? "#4B3BF5" : "#fff", eye = light ? "#fff" : "#4B3BF5";
  return `<svg width="${size}" height="${size}" viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" rx="12" fill="${bg}"/><path d="M20 6.5v4" stroke="${fg}" stroke-width="2.2" stroke-linecap="round"/><circle cx="20" cy="5.6" r="2.3" fill="#8CF5C8"/><rect x="8" y="11.5" width="24" height="18.5" rx="8" fill="${fg}"/><circle cx="15.6" cy="20" r="2.4" fill="${eye}"/><circle cx="24.4" cy="20" r="2.4" fill="${eye}"/><path d="M16.3 24.6q3.7 2.6 7.4 0" stroke="${eye}" stroke-width="1.9" fill="none" stroke-linecap="round"/><path d="M5.5 18v6M34.5 18v6" stroke="${fg}" stroke-width="2.4" stroke-linecap="round"/></svg>`;
}

/* ===== AI chatbot engine (English / French) with lead capture ===== */
const BOT = (function(){
  const norm = s => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[’']/g," ").replace(/[^a-z0-9@.\s]/g," ").replace(/\s+/g," ").trim();
  const lk = (l,h)=>({l,h});
  const svcOf = t => /\b(chatbot|bot|assistant|agent)\b/.test(t) && /\b(site|website|web)\b/.test(t) ? "Website + AI chatbot" : /\b(chatbot|bot|assistant|agent)\b/.test(t) ? "AI chatbot" : /\b(video|videos|motion|film|ad|ads|animation)\b/.test(t) ? "Motion video / ad" : /\b(website|site|landing|web|shop|store|ecommerce|boutique)\b/.test(t) ? "Website" : "";
  const I = [
    ["order", /\b(order|hire|buy|purchase|get started|start a project|start my project|start now|work with you|work together|i want a|i want an|i want to (build|create|make|get|order|start)|i need a|i need an|i d like a|i would like a|quote|proposal|commander|devis|je veux un|je veux une|je voudrais|j aimerais|besoin d un|besoin d une|on commence|let s start|lets start|let s do it)\b/],
    ["howareyou", /\b(how are you|how r u|how are u|how s it going|hows it going|how is it going|how do you do|how are things|what s up|whats up|wassup|ca va|comment ca va|comment vas tu|comment allez vous|tu vas bien)\b/],
    ["botid", /\b(are you (a )?(bot|robot|real|human|ai|person)|who are you|what are you|your name|what s your name|whats your name|tu es (un )?(robot|humain|reel)|qui es tu|c est quoi ton nom|ton nom)\b/],
    ["thanks", /\b(thanks|thank you|thx|ty|merci|perfect|parfait|great|awesome|cool|nice|super|genial)\b/],
    ["bye", /\b(bye|goodbye|see you|au revoir|a plus|ciao|bonne journee|bonne soiree)\b/],
    ["price", /\b(price|prices|pricing|cost|costs|how much|budget|rate|rates|expensive|cheap|prix|tarif|tarifs|combien|cout)\b/],
    ["time", /\b(how long|timeline|deadline|delivery|turnaround|fast|quick|when|delai|delais|combien de temps|duree|weeks|days)\b/],
    ["payment", /\b(pay|payment|invoice|deposit|paypal|stripe|bank|paiement|payer|acompte|facture)\b/],
    ["revisions", /\b(revision|revisions|changes|change|edit|modify|update|modifications|modifier)\b/],
    ["seo", /\b(seo|google|ranking|rank|search engine|referencement)\b/],
    ["ecommerce", /\b(ecommerce|e commerce|shop|store|shopify|boutique|sell online|vendre)\b/],
    ["hosting", /\b(hosting|host|domain|server|hebergement|domaine)\b/],
    ["chatbot", /\b(chatbot|chatbots|bot|bots|assistant|agent|openai|gpt|whatsapp)\b/],
    ["video", /\b(video|videos|film|films|motion|animation|ad|ads|explainer|promo)\b/],
    ["examples", /\b(example|examples|portfolio|projects|project|work|previous|clients|exemples|projets|realisations)\b/],
    ["website", /\b(website|websites|site|sites|web|landing|page|ui|ux|design|redesign|refonte)\b/],
    ["integrations", /\b(crm|salesforce|hubspot|calendar|calendly|integrat\w*|connect|zapier|n8n|automation|automatisation)\b/],
    ["language", /\b(language|languages|english|french|arabic|spanish|langue|langues|anglais|francais|arabe)\b/],
    ["services", /\b(services|service|what do you do|what can you do|offer|help me|que faites|tu fais quoi|vous faites)\b/],
    ["contact", /\b(contact|email|mail|phone|call|reach|meeting|whatsapp number|joindre|telephone|appel|appeler)\b/],
    ["location", /\b(where|based|location|remote|timezone|time zone|country|ou es tu|ou etes vous|pays)\b/],
    ["about", /\b(issam|about you|yourself|experience|background|qui est issam)\b/],
    ["yes", /^(yes|yeah|yep|sure|ok|okay|of course|why not|oui|d accord|ouais|bien sur|go)\b/],
    ["no", /^(no|nope|not now|later|non|pas maintenant)\b/],
    ["greet", /\b(hi|hello|hey|hola|yo|good morning|good evening|good afternoon|bonjour|bonsoir|salut|coucou|salam|slm)\b/]
  ];
  const START = {en:"Start a project", fr:"Démarrer un projet"};
  const R = {
    greet:{en:["Hi there! 👋 I'm Issam's AI assistant. I can answer questions about websites, AI chatbots and videos, or take your project details for Issam. What brings you here today?",null,["What services do you offer?","See examples","Start a project"]],
           fr:["Bonjour ! 👋 Je suis l'assistant IA d'Issam. Je réponds à vos questions sur les sites web, chatbots IA et vidéos, ou je transmets votre projet à Issam. Que puis-je faire pour vous ?",null,["Quels services ?","Voir des exemples","Démarrer un projet"]]},
    howareyou:{en:["I'm doing great, thanks for asking! 😊 Ready to help. Are you looking for a website, an AI chatbot or a video for your business?",null,["A website","An AI chatbot","A video"]],
               fr:["Je vais très bien, merci ! 😊 Vous cherchez un site web, un chatbot IA ou une vidéo pour votre activité ?",null,["Un site web","Un chatbot IA","Une vidéo"]]},
    botid:{en:["I'm Issam's AI assistant, a live example of the chatbots he builds for clients. I answer questions 24/7 and pass serious requests straight to Issam.",null,["Can you build me a chatbot?",START.en]],
           fr:["Je suis l'assistant IA d'Issam, un exemple réel des chatbots qu'il crée pour ses clients. Je réponds 24h/24 et transmets les demandes à Issam.",null,["Un chatbot pour moi ?",START.fr]]},
    about:{en:["Issam is a web designer and developer based in Casablanca, working with clients in Europe, the US and the Middle East. He also works in enterprise B2B sales for a global SaaS company, so everything he builds is designed to convert.",[lk("Why Issam","#about")],[START.en]],
           fr:["Issam est web designer et développeur basé à Casablanca, avec des clients en Europe, aux États-Unis et au Moyen-Orient. Il travaille aussi dans la vente B2B SaaS : tout est pensé pour convertir.",[lk("Pourquoi Issam","#about")],[START.fr]]},
    services:{en:["Issam offers three services:\n• Websites: premium, fast, built to convert\n• AI chatbots: answer and qualify leads 24/7\n• Motion videos & ads for SaaS and tech brands\nWhich one interests you?",[lk("See services","#services")],["A website","An AI chatbot","A video"]],
              fr:["Trois services :\n• Sites web premium qui convertissent\n• Chatbots IA qui répondent 24h/24\n• Vidéos motion et publicités\nLequel vous intéresse ?",[lk("Voir les services","#services")],["Un site web","Un chatbot IA","Une vidéo"]]},
    website:{en:["Issam designs and codes custom websites: mobile-first, fast, SEO-ready, with booking forms and analytics. A landing page takes about a week, a full site two to three weeks. Want to start one?",[lk("See websites","#work")],[START.en,"How much does it cost?"]],
             fr:["Issam conçoit des sites sur mesure : mobile, rapides, SEO, formulaires et statistiques. Environ 1 semaine pour une landing page, 2 à 3 pour un site complet. On démarre ?",[lk("Voir les sites","#work")],[START.fr,"Combien ça coûte ?"]]},
    chatbot:{en:["You're talking to one right now 🙂 Issam builds AI chatbots trained on your business: they answer questions, collect leads like this one and book calls, on your website, WhatsApp or Instagram. Setup takes a few days.",null,[START.en,"How much does it cost?"]],
             fr:["Vous en utilisez un 🙂 Issam crée des chatbots IA entraînés sur votre activité : réponses, collecte de leads et prise de rendez-vous, sur votre site, WhatsApp ou Instagram. Mise en place en quelques jours.",null,[START.fr,"Combien ça coûte ?"]]},
    video:{en:["Issam produces SaaS-style motion videos: launch films, explainers and ads in 16:9, 1:1 and 9:16, including work for CloudHealth by Broadcom. Usually one to two weeks.",[lk("Watch videos","#videos")],[START.en]],
           fr:["Issam réalise des vidéos motion style SaaS : lancements, explainers et publicités, notamment pour CloudHealth by Broadcom. En général 1 à 2 semaines.",[lk("Voir les vidéos","#videos")],[START.fr]]},
    examples:{en:["Here are live projects: an agency site with an AI agent, a car marketplace, a dental clinic and four directions for a marketing agency. You can open each one live.",[lk("See the work","#work"),lk("Clients worldwide","#clients")],[START.en]],
              fr:["Projets en ligne : site d'agence avec agent IA, marketplace auto, cabinet dentaire et quatre directions pour une agence marketing.",[lk("Voir les projets","#work")],[START.fr]]},
    price:{en:["Every project is different, so Issam sends a fixed-price proposal after understanding your needs. No hidden costs, no surprises. Share a few details and you'll get it within 24 hours.",null,[START.en,"How long does it take?"]],
           fr:["Chaque projet est différent : Issam envoie un devis à prix fixe après avoir compris votre besoin. Aucun coût caché. Donnez quelques détails et recevez-le sous 24 h.",null,[START.fr,"Quel délai ?"]]},
    time:{en:["Typical timelines:\n• Landing page: about 1 week\n• Full website: 2 to 3 weeks\n• AI chatbot: a few days\n• Motion video: 1 to 2 weeks",null,[START.en]],
          fr:["Délais habituels :\n• Landing page : environ 1 semaine\n• Site complet : 2 à 3 semaines\n• Chatbot IA : quelques jours\n• Vidéo : 1 à 2 semaines",null,[START.fr]]},
    payment:{en:["Usually 50% to start and 50% at launch, by bank transfer or PayPal. Everything is written in the proposal before we begin."],fr:["En général 50 % au démarrage et 50 % à la livraison, par virement ou PayPal. Tout est écrit dans le devis."]},
    revisions:{en:["Revisions are included at the design stage and after launch Issam stays available for changes. You'll never be stuck with something you don't like."],fr:["Les modifications sont incluses pendant le design, et Issam reste disponible après la mise en ligne."]},
    seo:{en:["Yes, every site is SEO-ready: fast loading, clean structure, meta tags, sitemap and Google Analytics set up from day one."],fr:["Oui, chaque site est optimisé SEO : rapide, structure propre, balises, sitemap et Google Analytics."]},
    ecommerce:{en:["Yes, Issam builds online stores, either on Shopify or custom, with payments, product pages and a chatbot that helps buyers.",null,[START.en]],fr:["Oui, Issam crée des boutiques en ligne (Shopify ou sur mesure) avec paiement et chatbot.",null,[START.fr]]},
    hosting:{en:["Issam handles domain and hosting setup for you. You own everything: the code, the domain and the content."],fr:["Issam s'occupe du domaine et de l'hébergement. Tout vous appartient : code, domaine et contenu."]},
    integrations:{en:["Yes. Leads can go to email, Salesforce, HubSpot, Google Sheets or your calendar, and Issam builds automations with n8n."],fr:["Oui. Les leads peuvent aller vers l'email, Salesforce, HubSpot, Google Sheets ou votre agenda, avec des automatisations n8n."]},
    language:{en:["Issam works in English and French, and chatbots can answer in any language your customers speak, including Arabic and Spanish."],fr:["Issam travaille en anglais et en français, et les chatbots répondent dans toutes les langues, arabe et espagnol compris."]},
    contact:{en:[()=>`You can email Issam at ${CONFIG.email}, or I can take your details right here and he'll reply within 24 hours. Want to do that?`,null,[START.en]],
             fr:[()=>`Écrivez à ${CONFIG.email}, ou je prends vos coordonnées ici et Issam vous répond sous 24 h. On fait ça ?`,null,[START.fr]]},
    location:{en:["Issam is based in Casablanca and works fully remote with clients in Europe, the US and the Middle East, in time zones that overlap with yours."],fr:["Issam est basé à Casablanca et travaille à distance avec des clients en Europe, aux États-Unis et au Moyen-Orient."]},
    thanks:{en:["You're welcome! Anything else I can help with?",null,[START.en,"See examples"]],fr:["Avec plaisir ! Autre chose ?",null,[START.fr]]},
    bye:{en:["Thanks for stopping by! Whenever you're ready, I'm here. 👋"],fr:["Merci de votre visite, à bientôt ! 👋"]},
    yes:{en:["Great! Let's get your project started.",null,null,"order"],fr:["Parfait, démarrons votre projet.",null,null,"order"]},
    no:{en:["No problem. Feel free to ask me anything about websites, chatbots or videos.",null,["What services do you offer?","See examples"]],fr:["Pas de souci. Posez-moi vos questions sur les sites, chatbots ou vidéos.",null,["Quels services ?"]]},
    fallback:{en:["I'm not sure I got that. I can tell you about services, prices, timelines and examples, or take your project details so Issam can reply personally.",null,["What services do you offer?","How much does it cost?",START.en]],
              fr:["Je n'ai pas bien compris. Je peux vous parler des services, tarifs, délais et exemples, ou prendre votre demande pour Issam.",null,["Quels services ?","Combien ça coûte ?",START.fr]]}
  };
  const F = { // lead capture flow
    en:{ service:"Awesome, let's get your project started! 🚀 What do you need?", svcChips:["A website","An AI chatbot","A motion video","Website + chatbot"],
         name:s=>`${s} — great choice. What's your name?`, email:n=>`Nice to meet you, ${n}! What's the best email to reach you?`, bad:"Hmm, that doesn't look like a valid email. Could you check it?",
         details:"Perfect. Tell me a bit about your business and what you'd like (goal, deadline, any links).", confirm:d=>`Here's your request:\n• Service: ${d.service}\n• Name: ${d.name}\n• Email: ${d.email}\n• Project: ${d.message}\nShall I send it to Issam?`,
         send:"Send it ✓", restart:"Start over", sending:"Sending your request…", ok:d=>`Done! ✅ Issam received your request and will reply within 24 hours at ${d.email}. Anything else?`, fail:"I couldn't send it automatically. Tap below to email Issam directly with your details pre-filled.", mail:"Email Issam", cancel:"No problem, I've cancelled that. Ask me anything else!" },
    fr:{ service:"Super, démarrons votre projet ! 🚀 De quoi avez-vous besoin ?", svcChips:["Un site web","Un chatbot IA","Une vidéo","Site + chatbot"],
         name:s=>`${s}, excellent choix. Quel est votre nom ?`, email:n=>`Enchanté, ${n} ! Quelle est la meilleure adresse email pour vous joindre ?`, bad:"Cette adresse email ne semble pas valide. Pouvez-vous vérifier ?",
         details:"Parfait. Décrivez en quelques mots votre activité et votre besoin (objectif, délai, liens).", confirm:d=>`Voici votre demande :\n• Service : ${d.service}\n• Nom : ${d.name}\n• Email : ${d.email}\n• Projet : ${d.message}\nJe l'envoie à Issam ?`,
         send:"Envoyer ✓", restart:"Recommencer", sending:"Envoi en cours…", ok:d=>`C'est envoyé ! ✅ Issam vous répondra sous 24 h à ${d.email}. Autre chose ?`, fail:"L'envoi automatique a échoué. Touchez ci-dessous pour écrire directement à Issam.", mail:"Écrire à Issam", cancel:"Pas de souci, c'est annulé. Posez-moi une autre question !" }
  };
  const Q = {en:["Start a project","What services do you offer?","How much does it cost?","See examples"],fr:["Démarrer un projet","Quels services ?","Combien ça coûte ?","Voir des exemples"]};
  const fmt = s => esc(s).replace(/\n/g,"<br>");
  function create(root, opts){
    root.innerHTML = `<div class="chat-top"><div class="av">${botLogo(42,true)}</div><div><strong>Issam AI</strong><small><i class="on-dot"></i>Online · replies instantly</small></div><button class="x" type="button" aria-label="Close chat">×</button></div>
      <div class="chat-body" data-lenis-prevent aria-live="polite"></div><div class="chips"></div>
      <form class="chat-form" autocomplete="off"><input type="text" maxlength="500" placeholder="Ask anything or start a project…" aria-label="Message" enterkeyhint="send"><button type="submit" aria-label="Send"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg></button></form>`;
    const body = $(".chat-body",root), input = $("input",root), chips = $(".chips",root);
    let lang = "en", busy = false, history = [], flow = null;
    const detect = raw => { const t = norm(raw); if (/\b(bonjour|bonsoir|salut|merci|combien|tarif|prix|delai|voudrais|besoin|vous|votre|pourquoi|comment|quel|quelle|projet|je|un site|une video|ca va|oui|d accord|commander|devis|demarrer)\b/.test(t)) return "fr"; if (/\b(the|you|what|how|i|my|is|are|can|do|a website|hello|hi|yes|ok)\b/.test(t)) return "en"; return lang; };
    const scroll = ()=> body.scrollTo({top: body.scrollHeight, behavior:"smooth"});
    function add(who, html, acts){
      const row = document.createElement("div"); row.className = "mrow "+who;
      row.innerHTML = (who==="bot" ? `<span class="mav">${botLogo(28,false)}</span>` : "") + `<div class="msg ${who}">${html}${acts&&acts.length?`<div class="go">${acts.map(a=>`<a href="${a.h}"${a.ext?' target="_blank" rel="noopener noreferrer"':''}>${esc(a.l)}</a>`).join("")}</div>`:""}</div>`;
      body.appendChild(row); scroll(); return row;
    }
    const typing = ()=> add("bot", '<span class="typing"><i></i><i></i><i></i></span>');
    function setChips(list){ chips.innerHTML = (list||Q[lang]).map(q=>`<button type="button"${q===START.en||q===START.fr||q===F.en.send||q===F.fr.send?' class="hot"':""}>${esc(q)}</button>`).join(""); $$("button",chips).forEach(b=>b.onclick=()=>send(b.textContent)); chips.scrollLeft = 0; }
    function say(text, acts, chipList, delay){
      return new Promise(res=>{ const t = typing(); setTimeout(()=>{ t.remove(); add("bot", fmt(text), acts); setChips(chipList); history.push({role:"assistant",content:text}); res(); }, delay ?? Math.min(500 + text.length*6, 1400)); });
    }
    const L = ()=>F[lang];
    async function flowStep(raw){
      const t = norm(raw);
      if (/^(cancel|stop|quit|exit|annuler|stop it|arrete)\b/.test(t)){ flow = null; return say(L().cancel, null, null); }
      if (flow.step === "service"){ flow.data.service = svcOf(t) || (/\+|both|les deux|site.*chat/.test(t) ? "Website + AI chatbot" : raw); flow.step = "name"; return say(L().name(flow.data.service), null, []); }
      if (flow.step === "name"){ flow.data.name = raw.replace(/^(my name is|i am|i m|je m appelle|je suis|moi c est)\s+/i,"").slice(0,60); flow.step = "email"; return say(L().email(flow.data.name), null, []); }
      if (flow.step === "email"){ const m = raw.match(/[^\s@]+@[^\s@]+\.[^\s@]{2,}/); if (!m) return say(L().bad, null, []); flow.data.email = m[0]; flow.step = "details"; return say(L().details, null, []); }
      if (flow.step === "details"){ flow.data.message = raw; flow.step = "confirm"; return say(L().confirm(flow.data), null, [L().send, L().restart]); }
      if (flow.step === "confirm"){
        if (raw === L().restart || /\b(start over|restart|recommencer|no|non)\b/.test(t)){ flow = {step:"service", data:{}}; return say(L().service, null, L().svcChips); }
        const d = {...flow.data, language: lang==="fr"?"French":"English", source:"AI chatbot"}; flow = null;
        const tp = typing(); setChips([]);
        try { await sendLead(d); tp.remove(); add("bot", fmt(L().ok(d))); setChips(); }
        catch(e){ tp.remove(); add("bot", fmt(L().fail), [{l:L().mail, h:mailtoLead(d), ext:true}]); setChips(); }
        return;
      }
    }
    function startFlow(raw){ const s = svcOf(norm(raw||"")); flow = {step: s ? "name" : "service", data: s ? {service:s} : {}}; return s ? say(L().name(s), null, []) : say(L().service, null, L().svcChips); }
    function local(raw){
      const t = norm(raw);
      if (raw === START.en || raw === START.fr) return {k:"order"};
      if (/^(a website|un site web)$/i.test(raw)) return {k:"website"}; if (/^(an ai chatbot|un chatbot ia)$/i.test(raw)) return {k:"chatbot"}; if (/^(a video|une video|une vidéo)$/i.test(raw)) return {k:"video"};
      const hit = I.find(([,re])=>re.test(t)); return {k: hit ? hit[0] : "fallback"};
    }
    async function send(raw){
      raw = (raw||"").trim(); if (!raw || busy) return; busy = true; input.value = "";
      lang = detect(raw); add("me", fmt(raw)); history.push({role:"user",content:raw});
      try {
        if (flow){ await flowStep(raw); return; }
        const {k} = local(raw);
        if (k === "order"){ await startFlow(raw); return; }
        if (CONFIG.chatApi && k === "fallback"){
          try { const r = await fetch(CONFIG.chatApi,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:history.slice(-12)})}); const d = await r.json(); await say(d.reply||d.message||d.content, null, null); return; } catch(e){}
        }
        const [txt, acts, ch, next] = R[k][lang] || R[k].en;
        await say(typeof txt==="function"?txt():txt, acts, ch);
        if (next === "order") await startFlow("");
      } finally { busy = false; }
    }
    $("form",root).addEventListener("submit", e=>{ e.preventDefault(); send(input.value); });
    body.addEventListener("click", e=>{ const a = e.target.closest(".go a"); if (!a || a.target) return; e.preventDefault(); if (opts && opts.onNav) opts.onNav(); goTo(a.getAttribute("href")); });
    $(".x",root).addEventListener("click", ()=> opts && opts.onClose && opts.onClose());
    setChips();
    add("bot", fmt("Hi! 👋 I'm Issam AI. Ask me anything about websites, AI chatbots or videos, or tap “Start a project” and I'll send your request straight to Issam."));
    return {send};
  }
  return {create};
})();
BOT.create($("#chatMain"));
(function(){
  const w = $("#widget"), fab = $("#fab"), tip = $("#fabTip");
  const close = ()=>{ w.classList.remove("open"); document.documentElement.classList.remove("chat-open"); };
  BOT.create($("#chatWidget"), {onClose:close, onNav:close});
  fab.innerHTML = botLogo(40,true);
  fab.addEventListener("click", ()=>{ const o = w.classList.toggle("open"); document.documentElement.classList.toggle("chat-open", o && innerWidth < 700); tip.classList.remove("show"); if (o && !isTouch) $("input", w).focus(); });
  setTimeout(()=>{ if (!w.classList.contains("open")) tip.classList.add("show"); setTimeout(()=>tip.classList.remove("show"), 6000); }, 5000);
})();

/* ===== Smooth scrolling (desktop) ===== */
let lenis = null;
if (window.Lenis && !reduce && !isTouch){
  lenis = new Lenis({lerp:.09, wheelMultiplier:1, smoothWheel:true});
  document.documentElement.classList.add("has-lenis");
  (function raf(t){ lenis.raf(t); requestAnimationFrame(raf); })(0);
}
function goTo(h){ const el = $(h); if (!el) return; if (lenis) lenis.scrollTo(el, {offset:-70, duration:1.4}); else el.scrollIntoView({behavior: reduce ? "auto" : "smooth"}); }
document.addEventListener("click", e=>{ const a = e.target.closest('a[href^="#"]'); if (!a || a.closest(".msg")) return; const h = a.getAttribute("href"); if (h.length < 2) return; e.preventDefault(); goTo(h); history.replaceState(null,"",h); });
